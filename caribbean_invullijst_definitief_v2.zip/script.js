
document.addEventListener("DOMContentLoaded", () => {
  console.log("App is geladen. (Hier zou de functionaliteit geladen worden)");
});
